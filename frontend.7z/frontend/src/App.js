import React, { Component } from 'react';
// import './App.css';
import Auth from './Components/Auth';

class App extends Component {
  render() {
    return (
      <div>
        <Auth />
      </div>
    );
  }
}

export default App;



