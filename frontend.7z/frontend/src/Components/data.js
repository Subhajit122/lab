const users =
    [
        { name: "Subhajit", email: "subho@gmail.com", password: "123456",occupation: 'Student' },
        { name: "Debjyoti", email: "debjyoti@gmail.com", password: "1234567",occupation: 'Nurse' },
        { name: "Anirban", email: "anirban@gmail.com", password: "123456",occupation: 'Business' },
        { name: "Saikat", email: "saikat@gmail.com", password: "654321",occupation: 'Doctor' }
    ]
export { users };